"""Publication figures for the DCB-NMF paper."""

from __future__ import annotations

import json
from pathlib import Path

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np

ROOT = Path(__file__).resolve().parent
FIGS = Path("/tmp/paper/figs")
FIGS.mkdir(parents=True, exist_ok=True)

plt.rcParams.update({
    "font.family": "serif",
    "font.serif": ["DejaVu Serif"],
    "font.size": 8,
    "axes.labelsize": 8,
    "axes.titlesize": 8,
    "legend.fontsize": 7,
    "xtick.labelsize": 7,
    "ytick.labelsize": 7,
    "axes.grid": True,
    "grid.alpha": 0.25,
    "grid.linewidth": 0.4,
    "axes.linewidth": 0.6,
    "lines.linewidth": 1.1,
    "savefig.bbox": "tight",
    "savefig.pad_inches": 0.02,
})

R = json.load(open(ROOT / "outputs" / "paper_raw.json"))
T = json.load(open(ROOT / "outputs" / "test_final.json"))
OVERLAPS = [0.25, 0.50, 0.75]
ALPHAS = [0.0, 0.2, 0.4, 0.5, 0.6, 0.8, 1.0]


def vals(name, overlap=None):
    src = T if (name == "full" or name.startswith("DCB@")) else R
    return np.array([
        r["scores"][name] for r in src
        if overlap is None or r["overlap"] == overlap
    ])


# ---------------------------------------------------------------- Figure 2
SHOW = [
    ("full", "DCB-NMF (ours)", "#c0392b", "o", "-"),
    ("MVDR+Mask", "MVDR+Mask", "#2c6fbb", "s", "--"),
    ("MVDR", "MVDR", "#117a45", "^", "-."),
    ("Ratio+DS", "Ratio+DS", "#8e44ad", "v", ":"),
    ("NMF", "NMF", "#7f7f7f", "d", (0, (3, 1, 1, 1))),
]

fig, axes = plt.subplots(1, 2, figsize=(7.0, 2.0))

ax = axes[0]
x = np.array(OVERLAPS)
for key, lab, col, mk, ls in SHOW:
    m = np.array([vals(key, o).mean() for o in OVERLAPS])
    s = np.array([vals(key, o).std() for o in OVERLAPS])
    ax.errorbar(x, m, yerr=s, color=col, marker=mk, ls=ls, ms=3.5,
                capsize=2, elinewidth=0.6, label=lab)
ax.set_xlabel(r"temporal overlap $\rho$")
ax.set_ylabel("SI-SDRi (dB)")
ax.set_xticks(x)
ax.axhline(0, color="k", lw=0.5)
ax.set_title("(a) robustness to temporal overlap")
ax.set_ylim(-16, 24)
ax.legend(ncol=2, loc="lower center", frameon=False, handlelength=2.2,
          columnspacing=1.0, borderpad=0.1)

ax = axes[1]
xa = np.array(ALPHAS)
for o, col, mk in zip(OVERLAPS, ["#f0a202", "#2c6fbb", "#c0392b"], ["o", "s", "^"]):
    m = np.array([vals(f"DCB@a{a:.1f}", o).mean() for a in ALPHAS])
    ax.plot(xa, m, color=col, marker=mk, ms=3.5, label=rf"$\rho$={o:.2f}")
m_all = np.array([vals(f"DCB@a{a:.1f}").mean() for a in ALPHAS])
s_all = np.array([vals(f"DCB@a{a:.1f}").std() for a in ALPHAS])
ax.plot(xa, m_all, color="k", marker="x", ms=4, lw=1.4, label="all conditions")
ax.axvline(0.4, color="k", lw=0.6, ls=":")
ax.set_xlabel(r"blend weight $\alpha$")
ax.set_ylabel("SI-SDRi (dB)")
ax.set_title(r"(b) sensitivity to $\alpha$ (test grid)")
lo, hi = ax.get_ylim()
ax.set_ylim(lo - 0.45 * (hi - lo), hi)
ax.text(0.415, hi - 0.05 * (hi - lo), r"$\alpha^\star$", fontsize=7, va="top")
ax.legend(ncol=2, loc="lower center", frameon=False, handlelength=2.2,
          columnspacing=1.2, borderpad=0.1)
fig.savefig(FIGS / "overlap_alpha.pdf")
plt.close(fig)

# ---------------------------------------------------------------- Figure 3
fig, ax = plt.subplots(figsize=(3.4, 2.15))
order = ["MVDR", "NMF", "Ratio+DS", "MVDR+Mask", "full"]
labels = ["MVDR", "NMF", "Ratio+DS", "MVDR+Mask", "DCB-NMF"]
data = [vals(k) for k in order]
bp = ax.boxplot(data, widths=0.55, patch_artist=True,
                medianprops=dict(color="k", lw=1.0),
                flierprops=dict(marker=".", ms=2.5, mfc="0.4", mec="0.4"),
                boxprops=dict(lw=0.6), whiskerprops=dict(lw=0.6),
                capprops=dict(lw=0.6))
for patch, c in zip(bp["boxes"], ["#dce6f2"] * 4 + ["#f5cfc9"]):
    patch.set_facecolor(c)
ax.set_xticklabels(labels, rotation=18, ha="right")
ax.set_ylabel("SI-SDRi (dB)")
ax.axhline(0, color="k", lw=0.5)
ax.set_title("distribution over the 45 test mixtures")
fig.savefig(FIGS / "boxplot.pdf")
plt.close(fig)

# ---------------------------------------------------------------- stats
from scipy import stats

for ref in ("MVDR+Mask", "MVDR"):
    d = vals("full") - vals(ref)
    w = stats.wilcoxon(vals("full"), vals(ref))
    print(f"DCB vs {ref:10s}: delta={d.mean():+.2f} dB, "
          f"wilcoxon p={w.pvalue:.2e}, win rate={float((d>0).mean()):.1%}")
print("alpha* std:", vals("DCB@a0.4").std(), " alpha0 std:", vals("DCB@a0.0").std())
print("figures written to", FIGS)
