# DCB-NMF — conference paper (IEEEtran, 5 pages incl. references)

## Build
```
latexmk -pdf main.tex
```
Requires `texlive-publishers` (IEEEtran.cls). Figure 1 is a standalone TikZ
file: `cd figs && pdflatex overview.tex`.

## Files
| file | role |
|---|---|
| `main.tex` | the paper |
| `refs.bib` | bibliography (21 entries — **verify before submitting**) |
| `tab_conditions.tex`, `tab_ablation.tex` | auto-generated tables |
| `figs/overview.tex/.pdf` | Fig. 1, system diagram (TikZ) |
| `figs/overlap_alpha.pdf` | Fig. 2, robustness + alpha sweep |
| `results/*.json` | every raw SI-SDRi score behind the paper |
| `summary.json` | all headline statistics |

## Reproducing the numbers
Copy the scripts into the `dcb_nmf` repo root and run, in order:
```
python eval_paper.py     # baselines + DCB alpha sweep, 45 test mixtures  (~10 min)
python dev_select.py     # dev-set choice of readout + alpha, 27 mixtures (~16 min)
python test_final.py     # final config on test + ablations               (~11 min)
python make_figs.py      # figures -> /tmp/paper/figs
python make_tables.py    # tables + summary.json
```
Test seeds are `1000 + 17*angle + 3*(100*overlap) + trial`; dev seeds add an
offset of 500000, so the two grids are disjoint.

## Selected configuration
Fixed on the development set only: arithmetic consensus readout,
consensus subset C = {MVDR, prior, masked-MVDR} (LCMV excluded),
blend weight alpha = 0.4, L = 2 outer iterations.

## Note on the code
`dcb_nmf/method.py` currently defaults to a *geometric* consensus mean with
alpha = 0.5. The dev set selects an *arithmetic* mean with alpha = 0.4
(+0.77 dB on test). `ablate.py::dcb_variant` implements both; consider making
the selected setting the library default.
