"""Emit LaTeX tables + a numeric summary for the DCB-NMF paper."""

from __future__ import annotations

import json
from pathlib import Path

import numpy as np
from scipy import stats

ROOT = Path(__file__).resolve().parent
OUT = Path("/tmp/paper")
R = json.load(open(ROOT / "outputs" / "paper_raw.json"))       # baselines (test)
T = json.load(open(ROOT / "outputs" / "test_final.json"))      # DCB + ablations (test)
D = json.load(open(ROOT / "outputs" / "dev_raw.json"))         # dev selection

ANGLES = [90.0, 120.0, 150.0]
OVERLAPS = [0.25, 0.50, 0.75]
ALPHAS = [0.0, 0.2, 0.4, 0.5, 0.6, 0.8, 1.0]
ALPHA_STAR = 0.4

METHODS = [
    ("NMF", "NMF (single-channel)"),
    ("DS", "DS"),
    ("Ratio+DS", "Ratio$+$DS"),
    ("MPDR", "MPDR"),
    ("MVDR", "MVDR"),
    ("LCMV", "LCMV"),
    ("GEV", "GEV"),
    ("MWF", "MWF"),
    ("ZF", "ZF"),
    ("AuxIVA", "AuxIVA"),
    ("MVDR+Mask", "MVDR$+$Mask"),
]


def pick(recs, name, angle=None, overlap=None):
    return np.array([
        r["scores"][name] for r in recs
        if (angle is None or r["angle"] == angle)
        and (overlap is None or r["overlap"] == overlap)
    ])


def vals(name, angle=None, overlap=None):
    src = T if (name == "full" or name.startswith("DCB@")) else R
    return pick(src, name, angle, overlap)


# --------------------------------------------------------------- main table
cols = [(a, o) for a in ANGLES for o in OVERLAPS]
ALLM = METHODS + [("full", r"\textbf{DCB-NMF (ours)}")]
means = {k: {c: vals(k, *c).mean() for c in cols} for k, _ in ALLM}
best = {c: max(means, key=lambda k: means[k][c]) for c in cols}

lines = [
    r"\begin{table*}[t]",
    r"\centering",
    r"\caption{Condition-wise mean SI-SDRi (dB) on the test grid: 5 trials per "
    r"cell, 45 mixtures in total, 4-microphone uniform linear array, 10~dB "
    r"diffuse-noise SNR. Columns are angular separation $\Delta\theta$ "
    r"$\times$ temporal overlap $\rho$. Every method shares the same Stage-1 "
    r"NMF masks, DOA estimates and STFT settings. DCB-NMF uses the single "
    r"configuration selected on a disjoint development set "
    r"(Sec.~\ref{sec:dev}); no per-condition tuning is performed. Best per "
    r"column in bold; the last column is the marginal mean $\pm$ standard "
    r"deviation over all 45 mixtures.}",
    r"\label{tab:conditions}",
    r"\setlength{\tabcolsep}{4.5pt}",
    r"\begin{tabular}{l" + "ccc" * 3 + "c}",
    r"\toprule",
    r"& \multicolumn{3}{c}{$\Delta\theta=90^\circ$} "
    r"& \multicolumn{3}{c}{$\Delta\theta=120^\circ$} "
    r"& \multicolumn{3}{c}{$\Delta\theta=150^\circ$} & \\",
    r"\cmidrule(lr){2-4}\cmidrule(lr){5-7}\cmidrule(lr){8-10}",
    r"Method & " + " & ".join([rf"$\rho${{=}}{o:.2f}" for _a in ANGLES for o in OVERLAPS])
    + r" & All \\",
    r"\midrule",
]
for key, lab in ALLM:
    cells = []
    for c in cols:
        v = means[key][c]
        cells.append(rf"\textbf{{{v:.2f}}}" if best[c] == key else f"{v:.2f}")
    allv = vals(key)
    tail = rf"{allv.mean():.2f}\,$\pm$\,{allv.std():.1f}"
    if key == "full":
        tail = rf"\textbf{{{allv.mean():.2f}}}\,$\pm$\,\textbf{{{allv.std():.1f}}}"
        lines.append(r"\midrule")
    lines.append(f"{lab} & " + " & ".join(cells) + f" & {tail} " + r"\\")
lines += [r"\bottomrule", r"\end{tabular}", r"\end{table*}"]
(OUT / "tab_conditions.tex").write_text("\n".join(lines), encoding="utf-8")

# --------------------------------------------------------------- alpha table
al = [
    r"\begin{table}[t]",
    r"\centering",
    r"\caption{Blend weight $\alpha$ on the test grid, marginalized over "
    r"angular separation. $\alpha{=}0$ disables the fusion readout but keeps "
    r"the closed loop; $\alpha{=}1$ is pure fusion. $\alpha^\star{=}0.4$ was "
    r"fixed on the development set.}",
    r"\label{tab:alpha}",
    r"\setlength{\tabcolsep}{4pt}",
    r"\begin{tabular}{l" + "c" * len(ALPHAS) + "}",
    r"\toprule",
    r"& \multicolumn{" + str(len(ALPHAS)) + r"}{c}{blend weight $\alpha$} \\",
    r"\cmidrule(lr){2-" + str(len(ALPHAS) + 1) + "}",
    r"Condition & " + " & ".join(f"{a:.1f}" for a in ALPHAS) + r" \\",
    r"\midrule",
]
for o in OVERLAPS:
    row = [vals(f"DCB@a{a:.1f}", overlap=o).mean() for a in ALPHAS]
    bi = int(np.argmax(row))
    al.append(
        rf"$\rho={o:.2f}$ & "
        + " & ".join(rf"\textbf{{{v:.2f}}}" if i == bi else f"{v:.2f}"
                     for i, v in enumerate(row)) + r" \\"
    )
al.append(r"\midrule")
row = [vals(f"DCB@a{a:.1f}").mean() for a in ALPHAS]
bi = int(np.argmax(row))
al.append(
    r"all & " + " & ".join(rf"\textbf{{{v:.2f}}}" if i == bi else f"{v:.2f}"
                           for i, v in enumerate(row)) + r" \\"
)
al += [r"\bottomrule", r"\end{tabular}", r"\end{table}"]
(OUT / "tab_alpha.tex").write_text("\n".join(al), encoding="utf-8")

# --------------------------------------------------------------- ablation
VAR = [
    ("full", r"\textbf{DCB-NMF (full)}"),
    ("open_loop", r"\;\; w/o closed loop ($L{=}1$)"),
    ("no_lcmv", r"\;\; w/o LCMV branch"),
    ("no_shared_basis", r"\;\; w/o shared basis"),
    ("geo_mean", r"\;\; geometric readout"),
    ("lcmv_in_consensus", r"\;\; LCMV inside $\mathcal{C}$"),
]
base = pick(T, "full").mean()
ab = [
    r"\begin{table}[t]",
    r"\centering",
    r"\caption{Ablation on the test grid at $\alpha^\star{=}0.4$, split by "
    r"temporal overlap. $\Delta$ is the change in the all-condition mean "
    r"relative to the full method. Only the closed loop is decisive; the "
    r"readout details matter by less than 1~dB.}",
    r"\label{tab:ablation}",
    r"\setlength{\tabcolsep}{3.5pt}",
    r"\begin{tabular}{lcccrr}",
    r"\toprule",
    r"& \multicolumn{3}{c}{overlap $\rho$} & & \\",
    r"\cmidrule(lr){2-4}",
    r"Variant & $0.25$ & $0.50$ & $0.75$ & All & $\Delta$ \\",
    r"\midrule",
]
for key, lab in VAR:
    r025, r050, r075 = (pick(T, key, overlap=o).mean() for o in OVERLAPS)
    allv = pick(T, key).mean()
    dstr = "---" if key == "full" else f"{allv - base:+.2f}"
    ab.append(f"{lab} & {r025:.2f} & {r050:.2f} & {r075:.2f} & {allv:.2f} & {dstr} " + r"\\")
    if key == "full":
        ab.append(r"\midrule")
ab += [r"\bottomrule", r"\end{tabular}", r"\end{table}"]
(OUT / "tab_ablation.tex").write_text("\n".join(ab), encoding="utf-8")

# --------------------------------------------------------------- dev table
DEVCFG = [
    ("geo_lcmvOut", r"geo., $\mathcal{C}{=}\{1,2,3\}$"),
    ("geo_lcmvIn", r"geo., $\mathcal{C}{=}\{1,2,3,4\}$"),
    ("arith_lcmvOut", r"\textbf{arith., $\mathcal{C}{=}\{1,2,3\}$}$^\star$"),
    ("arith_lcmvIn", r"arith., $\mathcal{C}{=}\{1,2,3,4\}$"),
]
dv = [
    r"\begin{table}[t]",
    r"\centering",
    r"\caption{Development-set selection of the consensus readout "
    r"(27 mixtures, seeds disjoint from the test grid). Mean SI-SDRi (dB); "
    r"the selected configuration ($\star$) and cell are in bold.}",
    r"\label{tab:dev}",
    r"\setlength{\tabcolsep}{3.5pt}",
    r"\begin{tabular}{l" + "c" * len(ALPHAS) + "}",
    r"\toprule",
    r"& \multicolumn{" + str(len(ALPHAS)) + r"}{c}{blend weight $\alpha$} \\",
    r"\cmidrule(lr){2-" + str(len(ALPHAS) + 1) + "}",
    r"Readout & " + " & ".join(f"{a:.1f}" for a in ALPHAS) + r" \\",
    r"\midrule",
]
gbest = max(
    ((c, a) for c, _l in DEVCFG for a in ALPHAS),
    key=lambda ca: pick(D, f"{ca[0]}@a{ca[1]:.1f}").mean(),
)
for key, lab in DEVCFG:
    cells = []
    for a in ALPHAS:
        v = pick(D, f"{key}@a{a:.1f}").mean()
        cells.append(rf"\textbf{{{v:.2f}}}" if (key, a) == gbest else f"{v:.2f}")
    dv.append(f"{lab} & " + " & ".join(cells) + r" \\")
dv += [r"\bottomrule", r"\end{tabular}", r"\end{table}"]
(OUT / "tab_dev.tex").write_text("\n".join(dv), encoding="utf-8")

# --------------------------------------------------------------- summary
dcb = pick(T, "full")
mm = pick(R, "MVDR+Mask")
mv = pick(R, "MVDR")
d = dcb - mm
summary = {
    "n_test": len(T), "n_dev": len(D),
    "dcb_mean": float(dcb.mean()), "dcb_std": float(dcb.std()),
    "mvdrmask_mean": float(mm.mean()), "mvdrmask_std": float(mm.std()),
    "mvdr_mean": float(mv.mean()), "mvdr_std": float(mv.std()),
    "delta_vs_mvdrmask": float(d.mean()),
    "delta_vs_mvdr": float((dcb - mv).mean()),
    "wilcoxon_p_vs_mvdrmask": float(stats.wilcoxon(dcb, mm).pvalue),
    "wilcoxon_p_vs_mvdr": float(stats.wilcoxon(dcb, mv).pvalue),
    "win_rate_vs_mvdrmask": float((d > 0).mean()),
    "win_rate_vs_mvdr": float(((dcb - mv) > 0).mean()),
    "per_overlap": {
        f"{o:.2f}": {
            "dcb": float(pick(T, "full", overlap=o).mean()),
            "mvdrmask": float(pick(R, "MVDR+Mask", overlap=o).mean()),
            "mvdr": float(pick(R, "MVDR", overlap=o).mean()),
            "delta": float(pick(T, "full", overlap=o).mean()
                           - pick(R, "MVDR+Mask", overlap=o).mean()),
        }
        for o in OVERLAPS
    },
    "ablation_delta": {
        k: float(pick(T, k).mean() - base) for k, _l in VAR if k != "full"
    },
    "dev_choice": {"config": gbest[0], "alpha": gbest[1]},
    "dcb_best_cells": sum(1 for c in cols if best[c] == "full"),
    "n_cells": len(cols),
}
(OUT / "summary.json").write_text(json.dumps(summary, indent=1), encoding="utf-8")
print(json.dumps(summary, indent=1))
